import java.util.Scanner;

public class DriverCls {

	public static void main(String[] args) {

		int i;
		Scanner s = new Scanner(System.in);
		System.out.println("***Good Morning***");
		System.out.println("SELECT 1 FOR CHOCOLATES");
		System.out.println("SELECT 2 FOR BEVERGES");
		System.out.println("SELECT 3 FOR SNACKS");
		i = s.nextInt();
		switch (i) {
		case 1:
			System.out.println("CHOCOLATES");
			Supercls1 s1;
			s1 = new Supercls1();
			s1.chocolates();
			break;
		case 2:
			System.out.println("BEVERGES");
			Subcls1 s2;
			s2 = new Subcls1();
			s2.Beverges();
			break;
		case 3:
			System.out.println("SNACKS");
			DerivedCls s3;
			s3 = new DerivedCls();
			s3.Snacks();
		}
	}
}
